O conteúdo deste repositório não tem fins de disseminação de conteúdo ou qualquer outro propósito que prejudiqe alguma organização ou pessoa.

Os arquivos existentes tem o propósito de servir via CDN conteúdos estáticos.